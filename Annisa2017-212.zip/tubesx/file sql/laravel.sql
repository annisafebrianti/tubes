-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 08 Jul 2022 pada 16.28
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `agenda`
--

CREATE TABLE `agenda` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `judul` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jam_mulai` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jam_selesai` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgl_mulai` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgl_selesai` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `agenda`
--

INSERT INTO `agenda` (`id`, `judul`, `slug`, `deskripsi`, `tgl`, `jam_mulai`, `jam_selesai`, `tgl_mulai`, `tgl_selesai`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Maintenance', 'maintenance', '<p>Maintenance website</p>', '2022-07-04', '07:22', '09:24', '2022-07-05', '2022-07-05', 1, '2022-07-03 17:23:03', '2022-07-03 17:23:03');

-- --------------------------------------------------------

--
-- Struktur dari tabel `artikel`
--

CREATE TABLE `artikel` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `judul` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `kategori_artikel_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `artikel`
--

INSERT INTO `artikel` (`id`, `judul`, `slug`, `deskripsi`, `thumbnail`, `user_id`, `kategori_artikel_id`, `created_at`, `updated_at`) VALUES
(1, 'Pengertian, Kelebihan, dan Cara Menggunakan Joomla untuk Pemula', 'pengertian-kelebihan-dan-cara-menggunakan-joomla-untuk-pemula', '<p><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">Saat ini, banyak cara untuk membuat sebuah website dengan mudah dan tanpa harus belajar ilmu pemrograman secara menyeluruh. Banyak sekali platform yang menyediakan fitur untuk membuat sebuah website, salah satunya dengan menggunakan CMS. Joomla adalah CMS yang sering digunakan untuk pembuatan sebuah website maupun blog. Sebenarnya ada banyak sekali jenis CMS yang lain untuk memudahkan anda dalam mengembangkan sebuah situs, namun kali ini kami akan membahas apa itu Joomla dan bagaimana cara menginstal untuk pemula. Kami juga akan memberikan informasi terkait komparasi antara Joomla dengan WordPress. Pengertian joomla Joomla adalah salah satu jenis CMS (Content Management System) yang bersifat open source serta berbasis PHP dan MySQL. Dapat dibilang, Joomla merupakan satu dari sekian banyak CMS yang paling banyak digunakan di seluruh dunia. Banyak dari setiap hosting provider yang menyediakan CMS ini secara gratis. Joomla pertama kali dirilis pada tahun 2005 dan merupakan alternatif dari WordPress. Bagi anda yang masih pemula lebih cocok untuk menggunakan WordPress daripada CMS ini. Karena, Joomla mempunyai toolkit desain yang lebih kuat (powerful), serta lebih fleksibel dari sisi front end dan backend -nya. Kelebihan joomla</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">Banyak sekali fitur yang dapat anda gunakan dan kembangkan dalam pembuatan sebuah situs website. Di dalam setiap fitur Joomla juga memiliki berbagai kelebihan dan keunggulan dari sisi fungsionalitas bagi para pengguna (user). Berikut ini merupakan beberapa kelebihannya. 1. Postingan blog yang sederhana Pertama, Joomla dapat membuat sebuah blog dengan simple dan efektif. Jika anda seorang blogging, maka anda akan tertarik dan mudah untuk membuat artikel di dalam Joomla. Anda tidak perlu untuk mempelajari dan memiliki pengetahuan tentang bahasa pemrograman. Cukup hanya menekan tombol publish, artikel siap untuk dirilis. 2. Open source Salah satu alasan mengapa CMS Joomla banyak digunakan di berbagai negara karena bersifat open source. Infrastruktur di dalamnya menggunakan bahasa pemrograman PHP yang sering digunakan oleh software open source. Banyak developer (pengembang) yang membuat ekstensi baru karen CMS ini mempunyai infrastruktur yang open source. Baca juga: Apa itu CMS? Kenali Lebih Dalam Mengenai Fungsi, Macam, dan Manfaatnya 3. Mudah untuk digunakan Tujuan dari penggunaan content management system adalah untuk memudahkan pengguna dalam membuat halaman suatu website dengan cepat dan efisien. Anda tidak perlu membuka tab baru atau membutuhkan permission level. Sehingga, proses kerja menjadi lebih cepat dan menghemat proses upload konten atau page. 4. Sangat cocok untuk website e-commerce Joomla juga sangat cocok untuk membuat tampilan website e-commerce. Apabila anda memiliki bisnis online, maka kami merekomendasikan untuk membuat website dengan CMS ini. Banyak sekali fitur untuk pembuatan menu transaksi jual beli secara online. 5. Memiliki komunitas yang luas Joomla memiliki ratusan ribu pelanggan aktif yang siap untuk membantu anda jika mengalami kendala teknis maupun yang bersifat non-teknis. Anda juga dapat bergabung pada komunitas yang luas jika membutuhkan bantuan dan support apabila terjadi masalah pada website anda. 6. SEO friendly Kelebihan dari sebuah CMS adalah terletak pada SEO friendly. Anda tidak perlu khawatir untuk menggunakan CMS dan mendapatkan rangking tinggi pada mesin pencari Google, Bing, atau Yahoo. Ada banyak sekali fitur dan ekstensi untuk membantu anda dalam meningkatkan rangking halaman situs anda dengan optimasi SEO. 7. Mempunyai fitur yang fleksibel Keuntungan yang terakhir adalah faktor fleksibilitas dari CMS membuat banyak sekali pengguna aktif website untuk mencoba Joomla. Selain itu, Joomla juga menyediakan ribuan extension dan widget yang dapat anda manfaatkan untuk kebutuhan media sosial. Cara menggunakan joomla</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Setelah memahami pengertian dan kelebihan dari Joomla, selanjutnya masuk ke dalam topik bahasa mengenai cara menggunakan Joomla untuk pemula. Kami membagi menjadi tiga tahap awal untuk menginstall CMS ini. 1. Login pada cPanel Langkah yang pertama, anda dapat melakukan login pada halaman cPanel hosting. Kemudian, anda dapat memasukkan username dan password. Setelah itu anda dapat menekan button &acirc;&#128;&#156;Log in&acirc;&#128;&#157;. 2. Menginstal joomla Langkah yang kedua adalah bagaimana cara menginstal Joomla. Setelah anda berhasil login melalui cPanel, anda akan diarahkan pada halaman menu cPanel. Kemudian, cari menu Softaculous App Installer untuk mencari icon Joomla. Anda juga dapat memanfaatkan fitur search yang telah disediakan oleh cPanel.</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">Setelah itu, anda dapat memulai menginstal Joomla dengan menekan tombol &acirc;&#128;&#156;Install Now&acirc;&#128;&#157;. Kemudian, anda akan diminta untuk mengisi beberapa informasi penting seperti berikut ini:</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">&acirc;&#128;&cent; Versi Joomla yang akan diinstall Pada petunjuk ini akan menginformasikan mengenai proses instalasi versi Joomla terbaru.</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">&acirc;&#128;&cent; Memilih instalasi URL Anda dapat memilih domain yang akan diinstall dan menentukan lokasi instalasi Joomla. Anda juga dapat mengosongkan direktori dan secara otomatis akan terinstall dalam folder public_html hosting.</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">&acirc;&#128;&cent; Site Name (Nama situs) Informasi berikutnya, anda dapat mengisi nama dari situs website anda.</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">&acirc;&#128;&cent; Site Description (Deskripsi situs) Selanjutnya, mengisi informasi deskripsi website yang akan anda buat.</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">&acirc;&#128;&cent; Import Sample Data Pada tahap ini, anda dapat memilih None atau dikosongkan saja.</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">&acirc;&#128;&cent; Admin Username dan Password Masukkan username dan password untuk dapat masuk pada halaman utama Joomla. Pastikan untuk mengisi password dengan benar dan indikator menunjukkan strong password. Supaya password anda tidak mudah untuk ditebak atau diretas oleh pengguna lain.</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">&acirc;&#128;&cent; Real Name (Nama asli) Isikan nama asli anda untuk ditampilkan di halaman dashboard Joomla.</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">&acirc;&#128;&cent; Admin email Selanjutnya, mengisikan alamat email aktif anda untuk proses verifikasi akun.</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">&acirc;&#128;&cent; Memilih bahasa (Select Language) Dan informasi terakhir, yaitu memilih bahasa yang akan anda gunakan pada menu dashboard pada Joomla.</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">3. Login pada menu halaman admin joomla Setelah anda berhasil mengisi semua informasi tersebut, maka anda akan secara otomatis diarahkan pada menu login Joomla. Gunakan username dan password yang berhasil anda buat sebelumnya, dan klik &acirc;&#128;&#156;Log in&acirc;&#128;&#157;. Jika anda berhasil login, maka anda akan masuk pada tampilan dashboard awal Joomla. Proses instalasi telah berhasil dan CMS siap untuk digunakan. Anda dapat mulai untuk mengeksplorasi berbagai fitur yang disediakan oleh Joomla terkait pengembangan website dan menu halaman website. Cobalah untuk membuat artikel terlebih dahulu dan memulai untuk mempublikasikannya. Kemudian, membuat kategori dan mencoba beberapa ekstensi dan template Joomla. Jika anda masih bingung, dapat membuka forum diskusi atau tanya jawab dengan beberapa komunitas CMS yang ada di seluruh penjuru dunia. Joomla vs wordpress</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">Bagi anda yang sudah sering menggunakan CMS tentu sangat mengerti mengenai kelebihan dan kekurangannya. Baik dari sisi fungsionalitas, efektivitas, maupun kualitas. Kami akan memberikan beberapa informasi penting terkait perbandingan antara dua CMS yang populer ini, yaitu Joomla vs WordPress. Yang mana, kedua CMS tersebut memiliki kelebihan dan kekurangan masing &acirc;&#128;&#147; masing. Berikut ini merupakan beberapa poin mengenai komparasi antara kedua sistem tersebut. 1. Dari sisi kemudahan pengguna Untuk kedua jenis CMS ini memiliki proses instalasi yang dapat dijalankan secara otomatis, serta memiliki struktur dashboard yang mudah untuk dipahami. Namun, untuk fitur post editor dari WordPress sedikit lebih membingungkan jika dibandingkan dengan Joomla. 2. Tampilan Dari segi tampilan, Joomla tidak memiliki direktori template. Akan tetapi, user dapat menggunakan template yang berbeda untuk setiap halaman. Sedangkan WordPress memiliki opsi tema yang banyak. Namun, hanya bisa menggunakan satu jenis saja pada setiap halaman. 3. SEO Keduanya sama &acirc;&#128;&#147; sama dapat dioptimasi dengan efektif, baik dari fitur bawaan, maupun dari plugin dan ekstensinya. 4. Sistem keamanan Dari sisi keamanan, Joomla memiliki fitur otentikasi dua langkah built in, dan menyediakan ekstensi keamanan. Sedangkan WordPress menyediakan plugin keamanan serta memberikan pembaruan sistem keamanan pada setiap update. 5. Bantuan atau Support</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">Untuk bantuan sendiri, Joomla memiliki sumber informasi yang lebih sedikit daripada WordPress. Karena perbedaan komunitas yang jauh antara kedua CMS ini. Nah, dari beberapa informasi tersebut, kita dapat menarik beberapa informasi penting. Yang pertama, kami merekomendasikan untuk menggunakan WordPress untuk para pengguna yang masih pemula dan belum paham mengenai konsep dasar pengembangan website. Jika anda yang sudah mahir dan sering menggunakan CMS, kami menyarankan untuk menggunakan Joomla. Namun, tidak menutup kemungkinan anda dapat menggunakan kedua sistem ini. Karena keduanya sangat mudah untuk digunakan apabila anda tidak ingin untuk membuat situs web dengan coding sendiri. Baca juga: Drupal adalah: Pengertian, Fungsi, dan Keunggulan yang Dimiliki</span></div><p></p></p>\n', 'kDcKJK0Pxm-blog-3.1.jpg', 1, 1, '2022-07-02 02:31:04', '2022-07-02 02:31:04'),
(3, 'Apa itu canva', 'apa-itu-canva', '<p><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">Berbagai jenis konten digital bisa tercipta dengan bantuan aplikasi/software atau online tool pada platform tertentu. Jika Anda ingin membuat sebuah desain dengan mudah dan praktis, Canva adalah jawabannya. Platform ini bagaikan &acirc;&#128;&#156;angin segar&acirc;&#128;&#157; bagi orang-orang yang ingin mendesain tanpa harus menggunakan software yang susah dipahami. Terlebih sekarang konten digital menjadi bagian penting dalam upaya mempresentasikan diri ataupun bisnis ke dunia maya seperti website dan media sosial. Maka tak heran jika Canva adalah pilihan alternatif terbaik untuk menghasilkan desain grafis berkualitas tapi minim effort. Melalui artikel ini, kami akan memperkenalkan apa itu Canva secara lebih mendalam. Lalu Anda juga akan mengetahui berbagai macam fiturnya dan perbedaan Canva versi Free dan Pro. Apa Itu Canva? Canva adalah sebuah platform pembuatan desain grafis dan konten publikasi yang lebih mudah dan cepat daripada software grafis lainnya. Tools ajaib ini bisa Anda gunakan secara online melalui browser desktop atau download aplikasi mobile-nya melalui App atau Play Store. Selain itu, ia menawarkan dua versi yaitu versi gratis dan versi berbayar (Pro).</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">Singkat Canva Sejak 2013, platform ini berhasil merebut hati lebih dari 60 juta pengguna aktif bulanan dari 190 negara di dunia. Dan dari jutaan orang mengetahui apa itu Canva, sudah lebih dari 7 miliar desain berhasil tercipta. Berkat permasalahan yang Melanie Perkins, Cameron Adams, dan Cliff Obrecht temukan di lapangan bahwa banyak sekali orang yang ingin membuat desainnya sendiri dengan mudah. Hingga pada akhirnya terciptalah Canva yang mereka kemas dengan prinsip &acirc;&#128;&#156;make complex things simple&acirc;&#128;&#157;. Hingga saat ini, Canva adalah produk utama perusahaan dengan nama serupa dari Perth, Australia yang sudah berekspansi ke Manila, Filipina dan Beijing, China. Adapun berkat popularitasnya dan performanya sebagai tools easy-to-use, platform ini berhasil mendapatkan tiga penghargaan bergengsi, berikut ini detailnya. Enterprise Tech 30 2019 dalam kategori mid-stage (Winner) Google Play Award 2019 (Winner) Great Place to Work Award 2019 (Winner)</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">Canva Semenjak banyak orang mulai mengenal apa itu Canva, para pengembangnya terus berusaha menghadirkan inovasi layanannya. Alhasil, kini Anda bisa menggunakan platform ini untuk membuat berbagai macam desain untuk kebutuhan personal dan profesional. Adapun kegunaan Canva adalah: &acirc;&#128;&cent; Membuat presentasi mirip PowerPoint &acirc;&#128;&cent; Membuat konten Instagram untuk feed, Story, dan Ads dengan pilihan animasi atau static &acirc;&#128;&cent; Mendesain postingan, cover, Ads, event cover, Facebook video, dan story Facebook &acirc;&#128;&cent; Mengedit video untuk berbagai platform media sosial, seperti Instagram, Facebook, TikTok, Pinterest, LinkedIn, dan YouTube &acirc;&#128;&cent; Mendesain poster, flyer, brosur, iklan, postcard, business card, newsletter, dan invoice untuk kebutuhan bisnis dan sebagai digital marketing tools &acirc;&#128;&cent; Membantu menyusun format resume, CV, letterhead, proposal, sertifikat, serta berbagai kartu dan undangan &acirc;&#128;&cent; Menyusun infografis, mind map, kolase foto, virtual background, format kalender, worksheet, planner, peta konsep, dan wallpaper/background layar gadget.</span></div><div style=\"text-align: justify;\"><br></div><div style=\"text-align: justify;\"><span style=\"font-size: 1rem;\">Canva Sebagai platform pembuatan desain, tak heran jika Canva memiliki segudang tools dan fitur yang akan memanjakan penggunanya. Selain cukup powerful, fitur-fitur ini mudah untuk orang awam pahami dan gunakan sehingga siapapun bisa jago mendesain dalam hitungan menit. Supaya Anda lebih familiar dengan apa itu Canva, berikut ini adalah fitur-fitur andalannya. 1. Tersedia 750.000+ Template Fitur utama dan terbaik dari Canva adalah templatenya. Jumlahnya pun tak tanggung-tanggung, diketahui total template siap pakai untuk berbagai kebutuhan adalah lebih dari 750 ribu. Bahkan hampir setiap harinya ada template baru untuk kategori tertentu. Anda juga masih tetap bisa mengubah beberapa bagian desain dari template yang Anda pilih. Aplikasi ini benar-benar membuat desain jadi lebih praktis dan menyenangkan. 2. Ada 900+ Ilustrasi dan Icon Selain template Anda juga bisa menambahkan unsur desain dengan ilustrasi dan icon dari berbagai jenis tema. Ingin ilustrasi 3D? Ada. Atau ilustrasi animasi seperti GIF? Juga ada. Explore menunya untuk menemukan ilustrasi dan icon yang Anda butuhkan. 3. PDF Editor Jangan kira Anda tahu apa itu Canva hanya untuk membuat dan mengedit desain langsung dari halaman templatenya. Sebab, Anda bisa mengimport file PDF ke dalam halaman kerja lalu Anda jadikan tampilan desain online. File PDF tersebut akan diubah jadi elemen-elemen yang editable sehingga Anda bisa mengedit bagian-bagian tertentu secara instan. Setelah selesai mengedit dokumen tersebut, Anda bisa mendownloadnya ke dalam format SVG, PPT, atau PDF. 4. Canva Live Bagi Anda yang kerap harus melakukan presentasi secara online, kini Anda bisa gunakan Canva dengan fiturnya yang bernama Canva Live. Dengan fitur ini, Anda tak perlu menyiapkan platform video conference lain untuk mengadakan presentasi online. Kegunaan penting fitur Canva adalah meningkatkan partisipasi audience agar presentasi lebih interaktif. Contohnya audience bisa mengirim reaksi, komentar, dan pertanyaan saat presentasi berlangsung. Hebatnya lagi, fitur ini terjamin keamanannya karena siapapun yang ingin bergabung dengan presentasi harus memasukkan kode 6 digit dari Anda di canva.live. 5. Text Customization Anda tidak hanya bisa memanfaatkan apa itu Canva sebagai platform desain dan editing, melainkan juga bisa membuat dokumen dan file tekstual lainnya. Tentunya kebutuhan pembuatan dokumen online tersebut tidak akan optimal tanpa fitur teks. Tinggal pilih menu Text di sebelah kiri halaman editor lalu pilih jenis font, warna, dan ukuran yang diinginkan. Teks yang Anda buat dapat Anda percantik dengan berbagai efek animasi sehingga tampilan dokumen online jadi lebih dinamis. 6. Canva Teams Proses mendesain bisa dilakukan secara individual maupun berkelompok. Nah, jika Anda memiliki tim desain, maka Canva adalah platform terbaik untuk kebutuhan komunikasi dengan anggota tim desain lainnya. Hanya dengan menginvite anggota tim dan setting pengaturan access permission ke dalam halaman editor, tim desain Anda siap saling berkolaborasi menciptakan desain terbaiknya. 7. Grid Desain dan Foto Fungsi dari apa itu Canva juga sangat membantu dalam pengeditan foto. Mulai dari mempercantiknya dengan filter ataupun dengan grid yang berfungsi untuk mengatur layout foto agar lebih rapi. Fitur grid ini pun tersedia dalam berbagai tata letak dan jumlah frame, mulai dari 2-grid hingga yang paling banyak adalah 16-grid. 8. Desain Frame Percantik tampilan foto Anda dengan efek frame sehingga seperti pigura foto. Bentuk frame yang tersedia pun cukup beragam mulai dari frame standar, film foto, dan ada yang menyerupai foto polaroid. Sehingga Canva adalah tools tepat untuk Anda yang ingin membuat foto album atau galeri foto.</span></div><p></p></p>\n', 'pDomoOzNbm-blog-5.png', 1, 4, '2022-07-02 05:36:32', '2022-07-02 05:36:32');

-- --------------------------------------------------------

--
-- Struktur dari tabel `banners`
--

CREATE TABLE `banners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `judul` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `btn_txt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori_artikel`
--

CREATE TABLE `kategori_artikel` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nama_kategori` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `kategori_artikel`
--

INSERT INTO `kategori_artikel` (`id`, `nama_kategori`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Website', 'website', '2022-07-02 01:31:16', '2022-07-02 01:31:16'),
(2, 'Software', 'sistem-operasi', '2022-07-02 01:31:27', '2022-07-02 05:19:23'),
(3, 'CPanel', 'cpanel', '2022-07-02 01:31:45', '2022-07-02 01:31:45'),
(4, 'Teknologi', 'teknologi', '2022-07-02 05:20:07', '2022-07-02 05:20:07');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2021_03_11_230713_create_pengumuman_table', 1),
(6, '2021_03_11_230723_create_agenda_table', 1),
(7, '2021_03_12_170942_create_artikel_table', 1),
(8, '2021_03_12_170959_create_kategori_artikel_table', 1),
(9, '2021_03_12_171751_create_banners_table', 1),
(10, '2021_03_12_172043_create_navbars_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `navbars`
--

CREATE TABLE `navbars` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `judul` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengumuman`
--

CREATE TABLE `pengumuman` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `judul` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tgl` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pengumuman`
--

INSERT INTO `pengumuman` (`id`, `judul`, `deskripsi`, `tgl`, `slug`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Maintenance', '<p>Informasi kepada pengguna website!<br><br>Sehubungan dengan adanya maintenance mingguan maka website untuk sementara waktu tidak akan bisa di akses.&nbsp; Maintenance akan diadakan pada hari Selasa, 5 Juli 2022. Maintenance akan diadakan pada pukul 07.00 - 09.00. Diharapkan pengguna website dapat mengerti dengan adanya maintenance ini.&nbsp;<br><br><br><br></p>', '2022-07-04', 'maintenance', 1, '2022-07-03 17:10:32', '2022-07-03 17:10:32');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Annisa Ayuningtyas Eka Febrianti', 'annisa@example.com', NULL, '$2y$10$JPb8zmoHG9bYQ84oYAZOJuXapsstLWZGO7yVKGVjqoGl52QZJAz56', NULL, NULL, NULL, NULL, NULL),
(2, 'Berliana Dwi Nur Azizah', 'berliana@example.com', NULL, '$2y$10$JoO7oUmwiWOdVzKlC.BtyuBVqR0Qqg0Hr1W6zxGzsy1/GT4m635Ee', NULL, NULL, NULL, '2022-07-03 17:32:10', '2022-07-03 17:32:10');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `agenda`
--
ALTER TABLE `agenda`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `kategori_artikel`
--
ALTER TABLE `kategori_artikel`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `navbars`
--
ALTER TABLE `navbars`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `pengumuman`
--
ALTER TABLE `pengumuman`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `agenda`
--
ALTER TABLE `agenda`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `artikel`
--
ALTER TABLE `artikel`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `banners`
--
ALTER TABLE `banners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `kategori_artikel`
--
ALTER TABLE `kategori_artikel`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `navbars`
--
ALTER TABLE `navbars`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pengumuman`
--
ALTER TABLE `pengumuman`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
