<?php $__env->startSection('content'); ?>
<div class="regular-page-area section-padding-100">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="page-content">
                    <h4>About Us</h4>
                    <p>Website ini digunakan untuk mempermudah penyampaian pembelajaran yang mudah. 
                        Mengingat adanya pandemi yang menyebabkan terganggunya sarana pembelajaran. Website ini 
                        diharapkan mampu mengatasi kesulitan seseorang dalam mendapatkan materi yang di inginkan. 
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend.app',[
    'title' => 'About',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tubesx\resources\views/home/about.blade.php ENDPATH**/ ?>