<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col">
		<div class="card">
			<div class="card-header">
				<a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-success btn-sm">Kembali</a>
			</div>
			<div class="card-body">
				<form method="POST" action="<?php echo e(route('admin.users.update',$user->id)); ?>">
					<?php echo csrf_field(); ?>
					<?php echo method_field('PATCH'); ?>
					<div class="form-group">
						<label for="name">Full Name</label>
						<input value="<?php echo e($user->name); ?>" required="" class="form-control" type="" name="name" id="name" placeholder="">
					</div>
					<div class="form-group">
						<label for="email">Email</label>
						<input value="<?php echo e($user->email); ?>" required="" class="form-control" type="" name="email" id="email" placeholder="">
					</div>
					<div class="form-group">
						<label for="password">Password</label>
						<input value="<?php echo e($user->password); ?>" type="hidden" name="old_password">
						<input class="form-control" type="password" name="password" id="password" placeholder="">
						<small class="text-secondary">Kosongkan kolom password jika tidak ingin mengubah password</small>
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary btn-sm">UPDATE</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend.app',[
	'title' => 'Edit Users',
	'contentTitle' => 'Edit Users',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tubesx\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>